import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import {
  ArrowRight,
  Plane,
  ShoppingCart,
  Package,
  FileText,
  Warehouse,
  Shield,
  AlertTriangle,
  Truck,
  Ship,
} from 'lucide-react';

const services = [
  {
    icon: Plane,
    title: 'International Air Freight',
    description: 'Fast and reliable air cargo services to 220+ countries with express and economy options.',
    bullets: [
      'Express delivery (2–5 days)',
      'Economy options available',
      'Door-to-door service',
      'Live shipment tracking',
    ],
  },
  {
    icon: ShoppingCart,
    title: 'E-commerce Marketplace Solutions',
    description: 'Seamless shipping solutions for Amazon FBA, TikTok FBT, Walmart, eBay, Etsy, and Noon.',
    bullets: [
      'Amazon FBA prep & shipping',
      'TikTok FBT fulfillment',
      'Walmart marketplace support',
      'Multi-platform integration',
    ],
  },
  {
    icon: Package,
    title: 'E-commerce Fulfillment',
    description: 'Complete order fulfillment solutions for D2C brands expanding internationally.',
    bullets: [
      'Order processing',
      'Inventory management',
      'Returns handling',
      'Multi-channel integration',
    ],
  },
  {
    icon: FileText,
    title: 'Customs Clearance',
    description: 'Expert customs brokerage services ensuring smooth clearance at all international borders.',
    bullets: [
      'Documentation support',
      'Duty optimization',
      'Compliance management',
      'Fast clearance',
    ],
  },
  {
    icon: Warehouse,
    title: 'Warehousing & Distribution',
    description: 'Strategic warehouse locations for efficient storage and distribution across India.',
    bullets: [
      'Multiple locations',
      'Inventory management',
      'Pick & pack',
      'Same-day dispatch',
    ],
  },
  {
    icon: Shield,
    title: 'Cargo Insurance',
    description: 'Comprehensive insurance coverage protecting your valuable shipments worldwide.',
    bullets: [
      'Full coverage',
      'Competitive premiums',
      'Quick claims',
      'Global protection',
    ],
  },
  {
    icon: AlertTriangle,
    title: 'Dangerous Goods Delivery',
    description: 'IATA/IMDG-certified handling of hazardous materials including lithium batteries, chemicals, and restricted substances.',
    bullets: [
      'Lithium batteries (UN3480/UN3481)',
      'Flammable liquids & chemicals',
      'Proper classification & labelling',
      'Air, sea & road compliance',
    ],
    badge: 'Specialized',
  },
  {
    icon: Truck,
    title: 'Road Freight',
    description: 'Reliable road transport solutions across India and cross-border routes with full visibility.',
    bullets: [
      'Full truckload (FTL)',
      'Less than truckload (LTL)',
      'Cross-border trucking',
      'Real-time GPS tracking',
    ],
  },
  {
    icon: Ship,
    title: 'Ocean Freight',
    description: 'Cost-effective sea freight solutions for large volume cargo across major global trade lanes.',
    bullets: [
      'Full Container Load (FCL)',
      'Less than Container Load (LCL)',
      'Bulk cargo handling',
      'Port-to-port & door-to-door',
    ],
  },
];

export default function ServicesPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="border-b bg-gradient-to-br from-background via-background to-muted/30 py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-6">Our Services</h1>
            <p className="text-lg text-muted-foreground md:text-xl">
              Comprehensive freight and logistics solutions designed to meet every shipping need. From air cargo to e-commerce fulfillment, we have got you covered.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid — always 3 per row */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div
                  key={index}
                  className="relative flex flex-col rounded-2xl border border-slate-700 bg-gradient-to-br from-slate-800 via-slate-800 to-slate-900 p-6 shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-slate-500"
                >
                  {service.badge && (
                    <span className="absolute top-4 right-4 rounded-full bg-orange-500/20 px-2.5 py-0.5 text-xs font-semibold text-orange-400 border border-orange-500/30">
                      {service.badge}
                    </span>
                  )}

                  <div className="mb-6">
                    <Icon className="h-9 w-9 text-orange-400" strokeWidth={1.5} />
                  </div>

                  <h3 className="mb-3 text-lg font-bold text-white leading-snug pr-12">
                    {service.title}
                  </h3>

                  <p className="mb-5 text-sm text-slate-300 leading-relaxed">
                    {service.description}
                  </p>

                  <ul className="mt-auto space-y-2">
                    {service.bullets.map((bullet, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-200">
                        <span className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full bg-orange-400" />
                        {bullet}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t bg-muted/30 py-16 md:py-20">
        <div className="container text-center">
          <h2 className="mb-4">Need a Custom Solution?</h2>
          <p className="mx-auto mb-8 max-w-2xl text-lg text-muted-foreground">
            Every business has unique logistics needs. Contact us to discuss how we can create a tailored freight solution for your specific requirements.
          </p>
          <Link to="/contact">
            <Button size="lg">
              Get in Touch
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
