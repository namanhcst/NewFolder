// Backend type definitions for the freight management system

export interface ShipmentDetailsSnapshot {
  trackingNumber: string;
  status: 'pending' | 'in_transit' | 'delivered' | 'delayed';
  origin: string;
  destination: string;
  estimatedDelivery: string;
  currentLocation?: string;
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
  updates?: Array<{
    timestamp: string;
    location: string;
    status: string;
    description: string;
  }>;
}

export interface ActorInterface {
  getShipmentDetails: (trackingNumber: string) => Promise<ShipmentDetailsSnapshot | null>;
}
