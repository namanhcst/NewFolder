import { useQuery } from '@tanstack/react-query';
import { useInternetIdentity } from './useInternetIdentity';

interface ActorInterface {
  getShipmentDetails: (trackingNumber: string) => Promise<any>;
}

interface UseActorResult {
  actor: ActorInterface | null;
  isFetching: boolean;
  error: Error | null;
}

export function useActor(): UseActorResult {
  const { isConnected } = useInternetIdentity();

  const { data: actor, isFetching, error } = useQuery({
    queryKey: ['actor', isConnected],
    queryFn: async () => {
      if (!isConnected) {
        return null;
      }

      // Placeholder for actual actor initialization
      // This would create an authenticated actor instance connected to the backend canister
      const mockActor: ActorInterface = {
        getShipmentDetails: async (trackingNumber: string) => {
          console.log('Fetching shipment details for:', trackingNumber);
          return null;
        },
      };

      return mockActor;
    },
    enabled: isConnected,
  });

  return {
    actor: actor || null,
    isFetching,
    error: error as Error | null,
  };
}
