import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Truck, 
  Clock, 
  Globe, 
  Shield, 
  TrendingUp, 
  CheckCircle2,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import ServicePreviewGrid from '../components/ServicePreviewGrid';
import { useState, useEffect, useCallback } from 'react';

const slides = [
  {
    image: '/assets/generated/cargo-port.jpg',
    heading: 'Global Freight Solutions for Your Business',
    subtext: 'Reliable, efficient, and cost-effective logistics services connecting your business to the world. From air to ocean, we handle it all.',
  },
  {
    image: '/assets/generated/slider-warehouse.avif',
    heading: 'State-of-the-Art Warehousing & Distribution',
    subtext: 'Modern warehouse facilities with real-time inventory management, ensuring your goods are stored securely and dispatched on time.',
  },
  {
    image: '/assets/generated/slider-containers.avif',
    heading: 'End-to-End Container Shipping Worldwide',
    subtext: 'Full and less-than-container load solutions across major global trade lanes, backed by our trusted network of shipping line partners.',
  },
];

const highlights = [
  {
    icon: Clock,
    title: 'On-Time Delivery',
    description: '99.8% on-time delivery rate with real-time tracking and updates.',
  },
  {
    icon: Globe,
    title: 'Global Coverage',
    description: 'Serving 150+ countries with our extensive logistics network.',
  },
  {
    icon: Shield,
    title: 'Secure & Insured',
    description: 'Full cargo insurance and secure handling for peace of mind.',
  },
  {
    icon: TrendingUp,
    title: 'Cost Efficient',
    description: 'Optimized routes and competitive rates to maximize your savings.',
  },
  {
    icon: CheckCircle2,
    title: 'Customs Expertise',
    description: 'Seamless customs clearance with our expert brokerage team.',
  },
  {
    icon: Truck,
    title: '24/7 Support',
    description: 'Round-the-clock customer support for all your shipping needs.',
  },
];

export default function HomePage() {
  const [current, setCurrent] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goTo = useCallback((index: number) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrent(index);
      setIsTransitioning(false);
    }, 300);
  }, [isTransitioning]);

  const prev = () => goTo((current - 1 + slides.length) % slides.length);
  const next = useCallback(() => goTo((current + 1) % slides.length), [current, goTo]);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <div className="flex flex-col">
      {/* Hero Slider */}
      <section className="relative overflow-hidden bg-gray-900" style={{ height: '580px' }}>
        {/* Slides */}
        {slides.map((slide, i) => (
          <div
            key={i}
            className="absolute inset-0 transition-opacity duration-700"
            style={{ opacity: i === current ? 1 : 0, zIndex: i === current ? 1 : 0 }}
          >
            <img
              src={slide.image}
              alt=""
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-black/55 via-black/40 to-black/50" />
          </div>
        ))}

        {/* Content */}
        <div className="relative z-10 flex h-full items-center">
          <div className="container">
            <div className="mx-auto max-w-4xl text-center">
              <div
                className="space-y-6 transition-all duration-500"
                style={{ opacity: isTransitioning ? 0 : 1, transform: isTransitioning ? 'translateY(10px)' : 'translateY(0)' }}
              >
                <h1 className="text-white">{slides[current].heading}</h1>
                <p className="mx-auto max-w-2xl text-lg text-white/90 md:text-xl">
                  {slides[current].subtext}
                </p>
                <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
                  <Link to="/contact">
                    <Button size="lg" className="w-full sm:w-auto">
                      Get a Quote
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link to="/tracking">
                    <Button size="lg" className="w-full sm:w-auto bg-white text-gray-900 hover:bg-white/90">
                      Track Shipment
                    </Button>
                  </Link>
                  <Link to="/services">
                    <Button size="lg" variant="outline" className="w-full sm:w-auto border-white/30 bg-white/10 text-white hover:bg-white/20 hover:text-white">
                      View Services
                    </Button>
                  </Link>
                </div>
                <div className="flex flex-wrap justify-center gap-8 pt-2">
                  <div>
                    <div className="text-3xl font-bold text-primary">10+</div>
                    <div className="text-sm font-medium text-white/80">Years Experience</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-primary">150+</div>
                    <div className="text-sm font-medium text-white/80">Countries Served</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-primary">50K+</div>
                    <div className="text-sm font-medium text-white/80">Shipments</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Prev / Next arrows */}
        <button
          onClick={prev}
          className="absolute left-4 top-1/2 z-20 -translate-y-1/2 flex h-10 w-10 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-sm transition hover:bg-black/50"
          aria-label="Previous slide"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          onClick={next}
          className="absolute right-4 top-1/2 z-20 -translate-y-1/2 flex h-10 w-10 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-sm transition hover:bg-black/50"
          aria-label="Next slide"
        >
          <ChevronRight className="h-5 w-5" />
        </button>

        {/* Dot indicators */}
        <div className="absolute bottom-5 left-1/2 z-20 flex -translate-x-1/2 gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              className={`h-2 rounded-full transition-all duration-300 ${i === current ? 'w-6 bg-white' : 'w-2 bg-white/50 hover:bg-white/80'}`}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Highlights Section */}
      <section className="border-t bg-background py-16 md:py-24">
        <div className="container">
          <div className="mb-12 text-center">
            <h2 className="mb-4">Why Choose Di LOGISOLUTIONS</h2>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              We deliver excellence in every shipment with our commitment to reliability, security, and customer satisfaction.
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {highlights.map((highlight, index) => (
              <Card key={index} className="transition-shadow hover:shadow-soft">
                <CardHeader>
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <highlight.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{highlight.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{highlight.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Channel Partners Section */}
      <section className="border-t bg-muted/20 py-14 md:py-20">
        <div className="container">
          <div className="mb-10 text-center">
            <span className="mb-3 inline-block rounded-full bg-primary/10 px-4 py-1 text-sm font-semibold text-primary">
              Trusted Network
            </span>
            <h2 className="mb-3">Our Channel Partners</h2>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              We work with the world's leading airlines and shipping lines to provide you with the best routes, rates, and reliability.
            </p>
          </div>

          {/* Air Partners */}
          <div className="mb-12">
            <div className="mb-6 flex items-center gap-3">
              <div className="h-px flex-1 bg-border" />
              <span className="flex items-center gap-2 rounded-full border bg-background px-4 py-1.5 text-sm font-semibold text-muted-foreground">
                ✈️ Air Channel Partners
              </span>
              <div className="h-px flex-1 bg-border" />
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
              {[
                { name: 'Air India', logo: '/assets/logos/air-india.png', bg: 'bg-red-50', border: 'border-red-100' },
                { name: 'British Airways', logo: '/assets/logos/british-airways.png', bg: 'bg-blue-50', border: 'border-blue-100' },
                { name: 'DHL Express', logo: '/assets/logos/dhl.png', bg: 'bg-yellow-50', border: 'border-yellow-100' },
                { name: 'Emirates', logo: '/assets/logos/emirates.png', bg: 'bg-red-50', border: 'border-red-100' },
                { name: 'FedEx Express', logo: '/assets/logos/fedex.png', bg: 'bg-purple-50', border: 'border-purple-100' },
                { name: 'Vistara', logo: '/assets/logos/vistara.png', bg: 'bg-indigo-50', border: 'border-indigo-100' },
                { name: 'UPS', logo: '/assets/logos/ups.png', bg: 'bg-yellow-50', border: 'border-yellow-100' },
                { name: 'Etihad Airways', logo: '/assets/logos/etihad.png', bg: 'bg-amber-50', border: 'border-amber-100' },
                { name: 'Virgin Atlantic', logo: '/assets/logos/virgin-atlantic.png', bg: 'bg-red-50', border: 'border-red-100' },
                { name: 'Qatar Airways', logo: '/assets/logos/qatar-airways.png', bg: 'bg-purple-50', border: 'border-purple-100' },
              ].map((partner) => (
                <div
                  key={partner.name}
                  className={`flex flex-col items-center justify-center rounded-xl border ${partner.border} ${partner.bg} p-4 text-center transition-all hover:shadow-md hover:-translate-y-0.5 min-h-[120px]`}
                >
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="h-14 w-auto max-w-[140px] object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      const parent = target.parentElement;
                      if (parent) {
                        const text = document.createElement('span');
                        text.className = 'text-sm font-bold text-muted-foreground';
                        text.textContent = partner.name;
                        parent.appendChild(text);
                      }
                    }}
                  />
                  <p className="mt-2 text-xs font-medium text-muted-foreground">{partner.name}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Sea Partners */}
          <div>
            <div className="mb-6 flex items-center gap-3">
              <div className="h-px flex-1 bg-border" />
              <span className="flex items-center gap-2 rounded-full border bg-background px-4 py-1.5 text-sm font-semibold text-muted-foreground">
                🚢 Sea Channel Partners
              </span>
              <div className="h-px flex-1 bg-border" />
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
              {[
                { name: 'SCI', logo: '/assets/logos/sci.png', bg: 'bg-blue-50', border: 'border-blue-100' },
                { name: 'Maersk Line', logo: '/assets/logos/maersk.png', bg: 'bg-sky-50', border: 'border-sky-100' },
                { name: 'CMA CGM', logo: '/assets/logos/cma-cgm.png', bg: 'bg-blue-50', border: 'border-blue-100' },
                { name: 'MSC', logo: '/assets/logos/msc.png', bg: 'bg-gray-50', border: 'border-gray-200' },
                { name: 'ONE', logo: '/assets/logos/one.png', bg: 'bg-pink-50', border: 'border-pink-100' },
                { name: 'Hapag-Lloyd', logo: '/assets/logos/hapag-lloyd.png', bg: 'bg-orange-50', border: 'border-orange-100' },
              ].map((partner) => (
                <div
                  key={partner.name}
                  className={`flex flex-col items-center justify-center rounded-xl border ${partner.border} ${partner.bg} p-4 text-center transition-all hover:shadow-md hover:-translate-y-0.5 min-h-[120px]`}
                >
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="h-14 w-auto max-w-[140px] object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      const parent = target.parentElement;
                      if (parent) {
                        const text = document.createElement('span');
                        text.className = 'text-sm font-bold text-muted-foreground';
                        text.textContent = partner.name;
                        parent.appendChild(text);
                      }
                    }}
                  />
                  <p className="mt-2 text-xs font-medium text-muted-foreground">{partner.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="border-t bg-muted/30 py-16 md:py-24">
        <div className="container">
          <div className="mb-12 text-center">
            <h2 className="mb-4">Our Services</h2>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Comprehensive freight and logistics solutions tailored to your business needs.
            </p>
          </div>
          <ServicePreviewGrid />
          <div className="mt-12 text-center">
            <Link to="/services">
              <Button size="lg" variant="outline">
                View All Services
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t bg-primary py-16 text-primary-foreground md:py-20">
        <div className="container text-center">
          <h2 className="mb-4 text-primary-foreground">Ready to Ship with Us?</h2>
          <p className="mx-auto mb-8 max-w-2xl text-lg opacity-90">
            Get a customized quote for your freight needs. Our team is ready to help you find the best solution.
          </p>
          <Link to="/contact">
            <Button size="lg" variant="secondary">
              Contact Us Today
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
